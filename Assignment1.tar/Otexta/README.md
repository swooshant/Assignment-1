# Assignment-1
Otexta

Python Library Requirements:
* cryptography
* wolframalpha

To run the software in the project first confiugre the port number you wish to use in the client and server main files. Next run the wolf359.py on one host and the otexta.py on another host. For the client use the following command format ./otexta.py "Question" "IP address of server"
