import wolfram

# my app id - Sushant
app_id = "T72KQ9-LE373U33UW"
result = wolfram.askWolfram(app_id, "How old is obama?")
print(result)
result = wolfram.askWolfram(app_id, "How old is George Bush?")
print(result)
result = wolfram.askWolfram(app_id, "How old is Jay z?")
print(result)
result = wolfram.askWolfram(app_id, "Where is tupac hiding?")
print(result)